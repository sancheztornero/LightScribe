#!/bin/bash

# Define path to LightScribe datafile
rcpath=/etc/lightscribe.rc

# Define the output strings
outputStr[1]=Enhanced
outputStr[2]=Default

# Define ELCU key
key=UseBoostedSettings

# Ensure superuser status
touch /etc/noexist 1>/dev/null 2>&1
if [ $? -ne 0 ]; then
	# ERROR: Permission denied
	echo "Permission denied. Please run as system administrator."
	exit 1
fi
rm -f noexist

# Initialize to standard settings on first load
if [ "`grep $key $rcpath`" = "" ]; then
	echo "${key}=false;" >> $rcpath
	if [ $? -ne 0 ]; then
		echo "ERROR: Cannot write to ${rcpath}"
		exit 1
	fi
fi

# Detect the current contrast setting
if [ "`grep ${key}=true $rcpath`" = "" ]; then
	prevSetting=2
else
	prevSetting=1
fi

# Output the user prompt
echo "Current contrast setting: "${outputStr[$prevSetting]}
echo
echo "MODIFY CONTRAST SETTINGS:"
echo "1 This will make your labels darker, but you will experience a longer label time"
echo "2 This will reset your LightScribe contrast to default factory settings"
echo -n "Select new setting: "

# Read the user input
read choice
until [ "$choice" = "1" ] || [ "$choice" = "2" ]; do
	echo -n "Invalid input. Retry: "
	read choice
done

# Apply new settings while watching for failure
applyFailed=0
if [ ${choice} = "1" ]; then
	sed -i.bak 's/^UseBoostedSettings.*/UseBoostedSettings=true;/g' $rcpath
elif [ ${choice} = "2" ]; then
	sed -i.bak 's/^UseBoostedSettings.*/UseBoostedSettings=false;/g' $rcpath
else
	applyFailed=1
fi

# Output results
echo
if [ ${applyFailed} = "0" ]; then
	echo "${outputStr[$choice]} settings applied."
elif [ ${applyFailed} = "1" ]; then
	echo "ERROR: Cannot modify ${rcpath}"
	exit 1
fi

exit 0
