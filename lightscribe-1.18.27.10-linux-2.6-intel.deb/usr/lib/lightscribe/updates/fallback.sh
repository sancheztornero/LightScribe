#!/bin/sh
# This script will work on any distribution that has KDE or Gnome or one of the other mechanisms below.
# other systems will just get an xterm window (not at all useful but until we get a better solution 
# it acts as a placeholder.
# Be sure to preserve the "&" at the end of any lines launching any executable to allow the
# the executable to run in the background. Otherwise it will hang the calling app while the app  
# waits for the executable to finish.


# Use this template to add more mechanisms to the possible list below
#TEMPLATE=`whereis template`
#TEMPLATE_RESULT=$?
#
#if ( test "${TEMPLATE_RESULT}" -eq "0" )
#then
#        # open the URL with this mechanism
#        TEMPLATE_EXE=`echo ${TEMPLATE} | awk '{print $2}'`
#	if ( test -f "${TEMPLATE_EXE}" )
#	then
#		"${TEMPLATE_EXE}" "www.lightscribe.com/go/downloads/linux" &
#        	exit
#	fi
#fi


UPDATE_LINK=http://www.lightscribe.com/go/downloads/linux



#set -x 


####  KEEP KFMCLIENT first in the list.

KFMCLIENT_TMP=`whereis kfmclient`
KFMRESULT=$?

if ( test "${KFMRESULT}" -eq "0" )
then
        # open the URL with this mechanism
        KFMCLIENT=`echo ${KFMCLIENT_TMP} | awk '{print $2}'`
	if ( test -f "${KFMCLIENT}" )
	then
        	"${KFMCLIENT}" exec "${UPDATE_LINK}" &
        	exit
	fi
fi


GNOME_OPEN_TMP=`whereis gnome-open`
GNOME_OPEN_RESULT=$?

if ( test "${GNOME_OPEN_RESULT}" -eq "0" )
then
        # open the URL with this mechanism
        GNOME_OPEN=`echo ${GNOME_OPEN_TMP} | awk '{print $2}'`
	if ( test -f "${GNOME_OPEN}" )
	then
		"${GNOME_OPEN}" "${UPDATE_LINK}" &
        	exit
	fi
fi



FIREFOX=`whereis firefox`
FIREFOX_RESULT=$?

if ( test "${FIREFOX_RESULT}" -eq "0" )
then
        # open the URL with this mechanism
        FIREFOX_EXE=`echo ${FIREFOX} | awk '{print $2}'`
	if ( test -f "${FIREFOX_EXE}" )
	then
		"${FIREFOX_EXE}" "${UPDATE_LINK}" &
        	exit
	fi
fi



MOZILLA=`whereis mozilla`
MOZILLA_RESULT=$?

if ( test "${MOZILLA_RESULT}" -eq "0" )
then
        # open the URL with this mechanism
        MOZILLA_EXE=`echo ${MOZILLA} | awk '{print $2}'`
	if ( test -f "${MOZILLA_EXE}" )
	then
		"${MOZILLA_EXE}" "${UPDATE_LINK}" &
        	exit
	fi
fi









# no reliable way to open a URL so just fire off an xterm 
xterm &
