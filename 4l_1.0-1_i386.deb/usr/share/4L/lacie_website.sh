#!/bin/sh
# This script will work on any distribution that has KDE or Gnome or one of the other mechanisms below.
# Be sure to preserve the "&" at the end of any lines launching any executable to allow the
# the executable to run in the background. Otherwise it will hang the calling app while the app  
# waits for the executable to finish.


# Use this template to add more mechanisms to the possible list below
#TEMPLATE=`whereis template`
#TEMPLATE_RESULT=$?
#
#if ( test "${TEMPLATE_RESULT}" -eq "0" )
#then
#        # open the URL with this mechanism
#        TEMPLATE_EXE=`echo ${TEMPLATE} | awk '{print $2}'`
#	if ( test -f "${TEMPLATE_EXE}" )
#	then
#		"${TEMPLATE_EXE}" "http://www.lightscribe.com/user/support.aspx" &
#        	exit
#	fi
#fi


#get the localized adress
CODE=`expr substr "$LANG" 1 2`

if ( test "$CODE" = "ja" )
then URL="http://www.lacie.com/jp/lightscribe/";
elif ( test "$CODE" = "de" )
then URL="http://www.lacie.com/de/lightscribe/";
elif ( test "$CODE" = "fr" )
then URL="http://www.lacie.com/fr/lightscribe/";
elif ( test "$CODE" = "it" )
then URL="http://www.lacie.com/it/lightscribe/";
elif ( test "$CODE" = "es" )
then URL="http://www.lacie.com/es/lightscribe/";
else
URL="http://www.lacie.com/lightscribe/";
fi


#set -x 

PATH_LIST=`echo $PATH | sed "s/:/ /g"`

####  KEEP KFMCLIENT first in the list.

KFMCLIENT_TMP=`whereis -B $PATH_LIST -f kfmclient`
KFMRESULT=$?

if ( test "${KFMRESULT}" -eq "0" )
then
        # open the URL with this mechanism
        KFMCLIENT=`echo ${KFMCLIENT_TMP} | awk '{print $2}'`
	if ( test -f "${KFMCLIENT}" )
	then
        	"${KFMCLIENT}" exec "$URL" &
        	exit
	fi
fi


GNOME_OPEN_TMP=`whereis -B $PATH_LIST -f gnome-open`
GNOME_OPEN_RESULT=$?

if ( test "${GNOME_OPEN_RESULT}" -eq "0" )
then
        # open the URL with this mechanism
        GNOME_OPEN=`echo ${GNOME_OPEN_TMP} | awk '{print $2}'`
	if ( test -f "${GNOME_OPEN}" )
	then
		"${GNOME_OPEN}" "$URL" &
        	exit
	fi
fi



FIREFOX=`whereis -B $PATH_LIST -f firefox`
FIREFOX_RESULT=$?

if ( test "${FIREFOX_RESULT}" -eq "0" )
then
        # open the URL with this mechanism
        FIREFOX_EXE=`echo ${FIREFOX} | awk '{print $2}'`
	if ( test -f "${FIREFOX_EXE}" )
	then
		"${FIREFOX_EXE}" "$URL" &
        	exit
	fi
fi



MOZILLA=`whereis -B $PATH_LIST -f mozilla`
MOZILLA_RESULT=$?

if ( test "${MOZILLA_RESULT}" -eq "0" )
then
        # open the URL with this mechanism
        MOZILLA_EXE=`echo ${MOZILLA} | awk '{print $2}'`
	if ( test -f "${MOZILLA_EXE}" )
	then
		"${MOZILLA_EXE}" "$URL" &
        	exit
	fi
fi

